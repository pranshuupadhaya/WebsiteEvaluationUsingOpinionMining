from _overlapped import NULL
import json

from django.http.response import HttpResponse
from django.shortcuts import redirect
from django.shortcuts import render

from Website_evaluation_using_opinion_mining.forms import UserForm, SearchWebsiteForm
from Website_evaluation_using_opinion_mining.models import User , Comment , Website
from Website_evaluation_using_opinion_mining.sentiment import *
from Website_evaluation_using_opinion_mining.sentiment.Comment_to_Score import Comment_to_Score 
from Website_evaluation_using_opinion_mining.models import Stats 
from _decimal import Decimal


# Create your views here.
def search_it(request):
    website=Website.objects.filter(website_domain_name=request.POST['search'])
    if(website):
        request.session['cache']=website[0]
    print(website[0])
    return redirect('/website/')
    
def validateEmail( email ):
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    try:
        validate_email(email)
        return True
    except ValidationError:
        return False


    
def logout(request):
    request.session.flush()
    request.session['status']="successfully logged out!"
    return redirect('/login/')




#map html page with form,do validations and register the user
def register(request):
    # if this is a POST request we need to process the form data
    if 'user' in request.session:
        return redirect('/home/')
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = UserForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            form.save()
            request.session['status']="registration successfull!!"
            return redirect('/login/')
    # if a GET (or any other method) we'll redirect to register.html
    else:
        form = UserForm()
       

    return render(request, 'index.html',{'form':form})






#function redirecting to login page
def login_form(request):
    message=""
    print("inside login")
    if 'status' in request.session:
        message=request.session['status']
        request.session.flush()
    if 'user' not in request.session:
        return render(request, 'index.html',{"status":message})
    else:
        return redirect('/home/')
        
        
        
        
def home(request):
    if 'user' not in request.session:
        return redirect('/login/')
    else:    
        return render(request, 'home.html', {"user":request.session['user']})
    



def verify_login(request):
    input_req=request.POST['input']
    password= request.POST['password']
    if(validateEmail(input_req)):
        email=input_req
        if(User.objects.filter(email=email)):
            user=User.objects.filter(email=email)[0]
        else:
            user=NULL
        if(user!=NULL):
            if(user.password==password):
                request.session['user']=user                
                return redirect('/home/')
            else:    
                status="Password is incorrect for the given emailId!"
                
        
        else:
            status="No User with the given emailId exists!"
                
    else:
        username=input_req
        if(User.objects.filter(username=username)):
            user=User.objects.filter(username=username)[0]
        else:
            user=NULL

        if(user!=NULL):
            if(user.password==password):
                request.session['user']=user                
                return redirect('/home/')
            else:    
                status="Password is incorrect for the given Username!"
                
        
        else:
            status="No User with the given Username exists!"        
    request.session['status']=status    
    return redirect('/login/')
       
        
        
        
        

def search_website(request):
    
    if 'user' not in request.session:
        return redirect('/login/')
       
    if request.method == 'POST':
        if(request.POST.get('search_text',' ')):
            search_text=request.POST.get('search_text',' ')
        else:
            search_text=" "

    else:
        search_text=""
    
    websites=Website.objects.filter(website_domain_name__contains=search_text)
    j_webs=[]
    for w in websites:
        j_webs.append(str(w))
    if(websites):
        request.session['cache']=websites[0]
    else:
        request.session['cache']=NULL
#     print("cache:::::"+request.session['cache'])
    
    data=json.dumps(j_webs)
    
    return HttpResponse(data, content_type='application/json')   

def update(request,cid):
   
    print("---"+(cid[:-1]))
    c_pk=(cid[:-1])
    if 'user' not in request.session:
        return redirect('/login/')
    
    if request.method=="GET":
            #check if the user has commented already. from the user table
            c_id_l="P"+c_pk+"L"
            c_id_d="P"+c_pk+"D"
            request.session['user']=User.objects.get(username=request.session['user'].username)
            cmt=Comment.objects.get(pk=c_pk)
            
            if(cid[-1]=="L"):
                   
                    if c_id_d in request.session['user'].like_dislike_history:
                        temp=request.session['user'].like_dislike_history.replace(c_id_d,"")
                        request.session['user'].like_dislike_history=temp
                        request.session['user'].save()
                        
                        
                        if(cmt.total_dislikes>0):   
                            cmt.total_dislikes-=1
                            if(cmt.popularity>0):
                                cmt.popularity-=1
                            cmt.save()
                        user_u=cmt.user
                        if(user_u.total_dislikes_recieved>0):
                            user_u.total_dislikes_recieved-=1
                            user_u.save()
                        
                     
                    if c_id_l in request.session['user'].like_dislike_history:
                        
                     
                        temp=request.session['user'].like_dislike_history.replace(c_id_l,"")
                        request.session['user'].like_dislike_history=temp
                        request.session['user'].save()
                        
                        
                        if(cmt.total_likes>0):   
                            cmt.total_likes-=1
                            if(cmt.popularity>0):
                                cmt.popularity-=1
                            cmt.save()    
                        
                        user_u=cmt.user
                        if(user_u.total_likes_recieved>0):
                            user_u.total_likes_recieved-=1
                            user_u.save()       
                        
                    else:
                        request.session['user'].like_dislike_history+=c_id_l
                        request.session['user'].save()
                        cmt.total_likes+=1
                        cmt.popularity+=1
                        cmt.save()
                        
                        user_u=cmt.user
                        
                        user_u.total_likes_recieved+=1
                        user_u.save()
                      
                        
            elif(cid[-1]=="D"): 
                    
                    if c_id_l in request.session['user'].like_dislike_history:
                        
                    
                        temp=request.session['user'].like_dislike_history.replace(c_id_l,"")
                        request.session['user'].like_dislike_history=temp
                        request.session['user'].save()
                        
                        
                        if(cmt.total_likes>0):   
                            cmt.total_likes-=1
                            if(cmt.popularity>0):
                                cmt.popularity-=1
                            cmt.save()    
                        
                        user_u=cmt.user
                        if(user_u.total_likes_recieved>0):
                                user_u.total_likes_recieved-=1
                                user_u.save()       
                        
                    if c_id_d in request.session['user'].like_dislike_history:
                        temp=request.session['user'].like_dislike_history.replace(c_id_d,"")
                        request.session['user'].like_dislike_history=temp
                        request.session['user'].save()
                        
                        
                        if(cmt.total_dislikes>0):   
                            cmt.total_dislikes-=1
                            if(cmt.popularity>0):
                                cmt.popularity-=1
                            cmt.save()
                        user_u=cmt.user
                        if(user_u.total_dislikes_recieved>0):
                                user_u.total_dislikes_recieved-=1
                                user_u.save()
                        
                    else:
       
                        request.session['user'].like_dislike_history+=c_id_d
                        request.session['user'].save()
                        cmt.total_dislikes+=1
                        cmt.popularity+=1
                        cmt.save()
                        user_u=cmt.user
                        
                        user_u.total_dislikes_recieved+=1
                        user_u.save()
                

    else:
        return redirect("/home/")
    
    countq=[cmt.total_likes,cmt.total_dislikes]
    data=json.dumps(countq)
    
    return HttpResponse(data, content_type='application/json')              
             
     
    
    
    
    
                
def display_website_data(request):
    if 'user' not in request.session:
        return redirect('/login/') 

    comment=""
    user_comments=[]   
    if request.method=="POST" :
        #this will redirect the use4r back to home if the form is invalid
            if 'search' in request.POST:
                    form=SearchWebsiteForm(request.POST)
                    if not form.is_valid():
                            return render(request,"home.html",{'user':request.session['user'],'form':form})
                        
            if(request.session['cache']): #for an old website
                        status=""
                       
                        website=request.session['cache']
                        
                        if(user_comments):
                            print(user_comments[0].comment)
                        if 'search' in request.POST: #comes from the homepage
                                if(Comment.objects.filter(user=request.session['user'],website=website)):
                                    comment=Comment.objects.filter(user=request.session['user'],website=website)[0].comment
                        
                        if 'comment' in request.POST : #same page
                                
                                if(request.POST['comment']==""):
 
                                    if(Comment.objects.filter(user=request.session['user'],website=website)):
                                        Comment.objects.get(user=request.session['user'],website=website).delete()
                               
                                elif(Comment.objects.filter(user=request.session['user'],website=website)):#if comment already exists update it
                                        rating= Comment_to_Score(request.POST['comment']).get_score()
                                        Edit_comment=Comment.objects.get(user=request.session['user'],website=website)
                                        Edit_comment.comment=request.POST["comment"]
                                        Edit_comment.sentiment=rating
                                        Edit_comment.save()
                                        
                                else:  #if it does not exist create a new object and save it in database
                                    rating= Comment_to_Score(request.POST['comment']).get_score()
                                    Comment(user=request.session['user'],
                                                    website=website,
                                                    comment=request.POST['comment'],
                                                    sentiment=rating
                                                   ).save()
                                                   
                                comment=request.POST['comment']   
                                    #new website     
            else:
                
                status="This website has not been rated yet!  Be the first one to rate this!"
                website=Website(website_domain_name=request.POST['search'],rating=0)
                request.session['cache']=website
                website.save()
    else:
                        status=""
                       
                        website=request.session['cache']
                        if 'search' in request.POST: #comes from the homepage
                                if(Comment.objects.filter(user=request.session['user'],website=website)):
                                    comment=Comment.objects.filter(user=request.session['user'],website=website)[0].comment
   
    user_comments=Comment.objects.filter(website=website)
#     user_comments_Bydate=Comment.objects.all().order_by('date')[:5]
#     user_comments_ByPop=Comment.objects.all().order_by('popularity')[:5]
#     print(user_comments_Bydate)
#     print(user_comments_ByPop)
    if(Stats.objects.filter(website=website)):
        stats_web=Stats.objects.get(website=website)
        
        if(str(website.ratingD)[2:]=="0"):
            website.ratingD+=round(Decimal(0.1),1)
            website.save()
        if(str(website.ratingW)[2:]=="0"):
            website.ratingW+=round(Decimal(0.1),1)
            website.save()
        if(str(website.ratingM)[2:]=="0"):
            website.ratingM+=round(Decimal(0.1),1)
            website.save()
        if(str(website.ratingY)[2:]=="0"):
            website.ratingY+=round(Decimal(0.1),1)
            website.save()
        
        
        args={'website':website,'status':status,'user':request.session['user'],'user_comments':user_comments,'comment':comment,
          'rating_overall_web':website.rating,'rating_expert_web':stats_web.expert_user_sentiment,'rating_A_web':stats_web.age_groupA_sentiment,
          'rating_B_web':stats_web.age_groupB_sentiment,'rating_C_web':stats_web.age_groupC_sentiment,
          'rating_D_web':stats_web.age_groupD_sentiment,
          'male_web':stats_web.male_sentiment,
          'female_web':stats_web.female_sentiment,'day':website.ratingD,
          'week':website.ratingW,'month':website.ratingM,'year':website.ratingY}
    else:
            
            args={'website':website,'status':status,'user':request.session['user'],'user_comments':user_comments,'comment':comment,
              'rating_overall_web':'2.5','rating_expert_web':'2.5','rating_A_web':'2.5',
              'rating_B_web':'2.5','rating_C_web':'2.5',
              'rating_D_web':'2.5',
              'male_web':'2.5',
              'female_web':'2.5',
              'day':'2.5',
              'week':'2.5','month':'2.5','year':'2.5'}
    return render(request,'display_website_data.html',args)

