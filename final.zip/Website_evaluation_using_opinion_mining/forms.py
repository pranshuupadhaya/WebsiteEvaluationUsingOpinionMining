'''
Created on May 22, 2016

@author: pranshu01.trn
'''




from Website_evaluation_using_opinion_mining.models import User
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.forms import ModelForm, Form
from django.forms.fields import URLField
from django.utils.translation import gettext as _
from urllib.request import urlopen
import http.client
# def check(website):
# #     c = http.client.HTTPConnection(website)
#     ret = urlopen('http://173.194.65.94')
#     if ret.code == 200:
#         return False#     else:
#         return True
class UserForm(ModelForm):

    class Meta:
        model=User
        fields=['username','fullname','email','password','dob','gender','expert']
    
class SearchWebsiteForm(Form):
    search = URLField(validators=[RegexValidator(regex= r'http[s]{0,1}://[^/]+[.]+[^/]+$',
                     message=_('please enter a correct URL http://xx.xx etc'),code='invalid_URL')])
#     def clean_search(self):
#         print("---------------ssssssssssssssss---------------------------")
#         search = self.cleaned_data['search']
#         if check(search):
#             raise ValidationError("Website does not exist!! fool someone else yo nigga!! bboooooo")
#         return search