$(function(){
	
	$('#search').keyup(function()  {
		
		$.ajax({
			type:"POST",
			url:"/home/search/",
			data: {
				'search_text' : $('search').val()
//				csrfmiddlewaretoken implementation
			},
			success: searchSuccess,
			dataType: 'html'
		});
		 
	});
});


function searchSuccess(data,textStatus,jqXHR)
{
	$('#search-results').html(data);
}