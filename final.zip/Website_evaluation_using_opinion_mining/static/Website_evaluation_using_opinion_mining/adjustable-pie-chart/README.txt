A Pen created at CodePen.io. You can find this one at http://codepen.io/ejsado/pen/cLrlm.

 You can change the values in the HTML to adjust the pie slices. 