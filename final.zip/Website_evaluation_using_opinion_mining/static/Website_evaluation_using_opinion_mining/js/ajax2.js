$(function(){
	
	$(".btn-primary").click(function ()  {
		var id=$(this).attr('name');//id=2323L=name of like or dislike button and id of the label for like dislike count
		$.ajax({
			
			url:"/update/"+id+'/',
			l_id:id.slice(0,-1)+'L',
			d_id:id.slice(0,-1)+'D',
			success: function (data,textStatus,jqXHR)
						{	
							$('#'+this.l_id).text(data[0]);
							$('#'+this.d_id).text(data[1]);
						}
			
		});
		 
	});
});


