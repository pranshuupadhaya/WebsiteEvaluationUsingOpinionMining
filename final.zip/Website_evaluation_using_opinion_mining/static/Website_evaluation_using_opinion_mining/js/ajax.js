$(function(){
	
	$('#search').keyup(function()  {
		
		$.ajax({
			type:"POST",
			url:"/search/",
			data: {
				'search_text' : $('#search').val(),
				'csrfmiddlewaretoken':$("input[name=csrfmiddlewaretoken]").val()
			},
			success: searchSuccess,
			dataType: 'json'
		});
		 
	});
});


function searchSuccess(data,textStatus,jqXHR)
{		
	$('#search').autocomplete({
		source:data
	});

}