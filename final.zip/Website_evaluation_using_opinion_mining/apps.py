from django.apps import AppConfig


class WebsiteEvaluationUsingOpinionMiningConfig(AppConfig):
    name = 'Website_evaluation_using_opinion_mining'
