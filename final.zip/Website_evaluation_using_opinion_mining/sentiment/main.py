'''
Created on May 31, 2016

@author: pranshu01.trn
'''
from _datetime import date
from django.utils.timezone import now

if __name__ == '__main__':
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            min_date = date(current.year , current.month, current.day)
            print("max date ---->>",max_date)
            print("min date ---->>",min_date)
    