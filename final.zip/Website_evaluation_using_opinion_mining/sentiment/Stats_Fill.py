'''
Created on May 3, 2016

@author: pranshu01.trn
'''

from Website_evaluation_using_opinion_mining.models import Comment, Stats
from _datetime import date
from django.utils.timezone import now
class Stats_Fill(object):
  


    def __init__(self,web):
        self.__website=web
        self.__male=0
        self.__female=0
        self.__gA=0
        self.__gB=0
        self.__gC=0
        self.__gD=0
        self.__expert=0
        self.__allUser=0

                                
                                
    def fill_Male_Sentiment(self):
        try:
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__gender="M")
            if(Comment.objects.filter(website=self.__website,user__gender="M")):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__male=avg
        except Exception as e:
            print(str(e))
        
    
    def fill_Female_Sentiment(self):
        try:
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__gender="F")
            if(Comment.objects.filter(website=self.__website,user__gender="F")):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__female=avg
        except Exception as e:
            print(str(e))
    def fill_groupA_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year - 0, current.month, current.day)
            min_date = date(current.year - 18, current.month, current.day)
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date, user__dob__gte=min_date)
            if(Comment.objects.filter(website=self.__website,user__dob__lte=max_date, user__dob__gte=min_date)):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__gA=avg
        except Exception as e:
            print(str(e))
    def fill_groupB_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year - 19, current.month, current.day)
            min_date = date(current.year - 44, current.month, current.day)
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date, user__dob__gte=min_date)
            if(Comment.objects.filter(website=self.__website,user__dob__lte=max_date, user__dob__gte=min_date)):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__gB=avg
        except Exception as e:
            print(str(e))

    def fill_groupC_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year - 45, current.month, current.day)
            min_date = date(current.year - 64, current.month, current.day)
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date, user__dob__gte=min_date)
            if(Comment.objects.filter(website=self.__website,user__dob__lte=max_date, user__dob__gte=min_date)):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__gC=avg
        except Exception as e:
            print(str(e))
    def fill_groupD_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year - 65, current.month, current.day)
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            #max_date = date(current.year - 150, current.month, current.day)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date)
            if(Comment.objects.filter(website=self.__website,user__dob__lte=max_date)):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__gD=avg
        except Exception as e:
            print(str(e))
    def fill_Expert_Sentiment(self):
        try:
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__expert=True)
            if(Comment.objects.filter(website=self.__website,user__expert=True)):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__expert=avg
        except Exception as e:
            print(str(e))
    def fill_genUser_Sentiment(self):
        try:
            avg=2.5
            comments=Comment.objects.filter(website=self.__website)
            if(Comment.objects.filter(website=self.__website)):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__allUser=avg
        except Exception as e:
            print(str(e))
    def fill_All(self):
        self.fill_Male_Sentiment()
        self.fill_Female_Sentiment()
        self.fill_genUser_Sentiment()
        self.fill_Expert_Sentiment()
        self.fill_groupA_Sentiment()
        self.fill_groupB_Sentiment()
        self.fill_groupC_Sentiment()
        self.fill_groupD_Sentiment()
        Stats(  website=self.__website,
                male_sentiment=self.__male,
                female_sentiment=self.__female,
                age_groupA_sentiment=self.__gA,
                age_groupB_sentiment=self.__gB,
                age_groupC_sentiment=self.__gC,
                age_groupD_sentiment=self.__gD,
                expert_user_sentiment=self.__expert,
                general_user_sentiment=self.__allUser,
                ).save()
                
    def print_All(self):
        print("Website= ",self.__website.website_domain_name)
        print("Male= ",self.__male)
        print("Female= ",self.__female)
        print("groupA= ",self.__gA)
        print("groupB= ",self.__gB)
        print("groupC= ",self.__gC)
        print("groupD= ",self.__gD)
        print("Experts=",self.__expert)
        print("All Users= ",self.__allUser)
        