'''
Created on May 31, 2016

@author: pranshu01.trn
'''
'''
Created on May 31, 2016

@author: pranshu01.trn
'''
'''
Created on May 31, 2016

@author: pranshu01.trn
'''
from _datetime import date
from django.utils.timezone import now
from Website_evaluation_using_opinion_mining.models import Comment

from datetime import  timedelta
class fillByWeek(object):
      
       
    def __init__(self,web):
        self.__website=web
        self.__male=0
        self.__female=0
        self.__gA=0
        self.__gB=0
        self.__gC=0
        self.__gD=0
        self.__expert=0
        self.__allUser=0
        self.__ratingW=0
    
    def fill_Male_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__gender="M",date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__male=avg
        except Exception as e:
            print(str(e))
            
    def fill_Female_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__gender="F",date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__female=avg
        except Exception as e:
            print(str(e))
            
    def fill_groupA_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
            max_date1 = date(current.year - 0, current.month, current.day)
            min_date1 = date(current.year - 18, current.month, current.day)            
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date1, user__dob__gte=min_date1,date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__gA=avg
        except Exception as e:
            print(str(e))
            
    def fill_groupB_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
            max_date1 = date(current.year - 19, current.month, current.day)
            min_date1 = date(current.year - 44, current.month, current.day)            
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date1, user__dob__gte=min_date1,date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__gB=avg
        except Exception as e:
            print(str(e))
            
    def fill_groupC_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
            max_date1 = date(current.year - 45, current.month, current.day)
            min_date1 = date(current.year - 64, current.month, current.day)            
#             print("max date ---->>",max_date)
#             print("min date ---->>",min_date)
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date1, user__dob__gte=min_date1,date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__gC=avg
        except Exception as e:
            print(str(e))
            
    def fill_groupD_Sentiment(self):
        try:
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
            
            max_date1 = date(current.year - 65, current.month, current.day)           
#             print("max date ---->>",max_date)
            
            avg=2.5
            comments=Comment.objects.filter(website=self.__website,user__dob__lte=max_date1,date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                    
                n=len(comments)
                
                avg/=n
            self.__gD=avg
        except Exception as e:
            print(str(e))
            
            
    def fill_Expert_Sentiment(self):
        try:
            avg=2.5
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
            comments=Comment.objects.filter(website=self.__website,user__expert=True,date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__expert=avg
        except Exception as e:
            print(str(e))
    
    def fill_genUser_Sentiment(self):
        try:
            avg=2.5
            current = now().date()
            max_date = date(current.year , current.month, current.day)
            w = timedelta(weeks=1)
            min_date = date(current.year , current.month, current.day)-w
            comments=Comment.objects.filter(website=self.__website,date__lte=max_date, date__gte=min_date)
            if(comments):
                avg=0
                for c in comments:
                    avg+=round(((float(c.sentiment)+1.0)*2.5),2)
                n=len(comments)
                avg/=n
            self.__allUser=avg
        except Exception as e:
            print(str(e))
    def fill_All(self):
        self.fill_Male_Sentiment()
        self.fill_Female_Sentiment()
        self.fill_genUser_Sentiment()
        self.fill_Expert_Sentiment()
        self.fill_groupA_Sentiment()
        self.fill_groupB_Sentiment()
        self.fill_groupC_Sentiment()
        self.fill_groupD_Sentiment()
    def convert(self):
        try:
            self.fill_All()
            self.__ratingW=(0.1)*(self.__male+
                                        self.__female+
                                        self.__gA+
                                        self.__gB+
                                        self.__gC+
                                        self.__gD+
                                        self.__allUser)+(0.3)*(self.__expert)
            return self.__ratingW
        
        except Exception as e:
            print("for----week"+str(e))