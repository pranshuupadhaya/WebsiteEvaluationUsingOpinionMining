'''
Created on May 31, 2016

@author: pranshu01.trn

'''
from Website_evaluation_using_opinion_mining.sentiment.sentimentByTime.fillByDay import fillByDay
from Website_evaluation_using_opinion_mining.sentiment.sentimentByTime.fillByMonth import fillByMonth
from Website_evaluation_using_opinion_mining.sentiment.sentimentByTime.fillByWeek import fillByWeek
from Website_evaluation_using_opinion_mining.sentiment.sentimentByTime.fillByYear import fillByYear


class TimeFiller(object):
    def __init__(self,web):
        self.__website=web
    def fillIt(self):
        
        D=fillByDay(self.__website).convert()
        W=fillByWeek(self.__website).convert()
        M=fillByMonth(self.__website).convert()
        Y=fillByYear(self.__website).convert()
        print("---"+str(self.__website))
        print(D)
        print(W)
        print(M)
        print(Y)
        self.__website.ratingD=D
        self.__website.ratingM=M
        self.__website.ratingW=W
        self.__website.ratingY=Y
        self.__website.save()
