'''
Created on May 3, 2016

@author: pranshu01.trn
'''

from nltk.tokenize import sent_tokenize

from nltk.sentiment.vader import SentimentIntensityAnalyzer


class Comment_to_Score(object):
    def __init__(self, text):
        self.__text=text
        self.__list=[]
        self.__score=0
        
    def get_score(self):
        self.calculate_score()
        return self.__score

    def calculate_score(self):
#       
            
            try:
                sid = SentimentIntensityAnalyzer() 
                self.__list = sent_tokenize(self.__text, 'english')
                for sentence in self.__list:
                    ss = sid.polarity_scores(sentence)
#                     for k in sorted(ss):
#                         print('{0}: {1}, '.format(k, ss[k]), end='')
                    self.__score+=ss['compound']
                self.__score/=len(self.__list)     
                    
            except Exception as e:
                print(str(e))  