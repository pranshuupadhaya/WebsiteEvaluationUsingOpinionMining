from Website_evaluation_using_opinion_mining.models import Stats
from decimal import Decimal
class Stats_to_rating:
   
    
    
    def __init__(self,web):
        self.__website=web
    def convert(self):
        try:
            stats=Stats.objects.get(website=self.__website)
            self.__website.rating=Decimal(0.1)*( stats.male_sentiment+
                                        stats.female_sentiment+
                                        stats.age_groupA_sentiment+
                                        stats.age_groupB_sentiment+
                                        stats.age_groupC_sentiment+
                                        stats.age_groupD_sentiment+
                                        stats.general_user_sentiment)+Decimal(0.3)*(stats.expert_user_sentiment)
            self.__website.save()
        
        except Exception as e:
            print(str(e))