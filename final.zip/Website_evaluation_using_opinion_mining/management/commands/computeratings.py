'''
Created on May 30, 2016

@author: pranshu01.trn
'''
from django.core.management.base import BaseCommand
from Website_evaluation_using_opinion_mining.models import Website 
from Website_evaluation_using_opinion_mining.sentiment.Stats_Fill import Stats_Fill
from Website_evaluation_using_opinion_mining.sentiment.Stats_to_rating import Stats_to_rating
from Website_evaluation_using_opinion_mining.sentiment.sentimentByTime.TimeFiller import TimeFiller
class Command(BaseCommand):

    def handle(self ,*args, **options):
        list_web=Website.objects.all()
        if(list_web):
            for website in list_web:
                s=Stats_Fill(website)
                s.fill_All()
                s.print_All()
                Stats_to_rating(website).convert() 
    
        if(list_web):
            for website in list_web:
                TimeFiller(website).fillIt()
                 
                 

