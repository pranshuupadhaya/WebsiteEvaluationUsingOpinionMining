'''
Created on May 31, 2016

@author: pranshu01.trn
'''
from django.core.management.base import BaseCommand
from Website_evaluation_using_opinion_mining.models import User
class Command(BaseCommand):

    def handle(self ,*args, **options):
        list_user=User.objects.all()
        if(list_user):
            for user in list_user:
                if(user.total_likes_recieved<user.total_dislikes_recieved and user.expert==True):
                    user.expert=False
                    user.save()
                    print("removed user"+str(user))
                    
    
        
                 
