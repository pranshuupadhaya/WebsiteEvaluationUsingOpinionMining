from django.contrib import admin
from Website_evaluation_using_opinion_mining.models import Website,User,Message,Comment,Stats

# Register your models here.
admin.site.register(User)
admin.site.register(Message)
admin.site.register(Website)
admin.site.register(Stats)

class myModel(admin.ModelAdmin):
    pass
#         readonly_fields=('date',)

admin.site.register(Comment,myModel)