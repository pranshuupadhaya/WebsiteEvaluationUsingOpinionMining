from django.db import models
from django.core import validators
from django.contrib.auth.models import User
from django.utils.translation import gettext as _
from django.utils.timezone import now

# Create your models here.
class User(models.Model):
    username = models.CharField(
     
        max_length=30,
        unique=True,
        help_text=_('enter letters followed by numbers if required'),
        validators=[
            validators.RegexValidator(
               regex= r'[A-Za-z]+[0-9]*$', message=_('invalid username'),code='invalid_exp')
            ,
        ],
        error_messages={
            'unique': _("A user with that username already exists."),
        },
    )
    fullname=models.CharField(max_length=100)
    email=models.EmailField(primary_key=True)
    password=models.CharField(max_length=50)
    dob=models.DateField()
    gender=models.CharField(max_length=1)
    expert=models.BooleanField()
    trust=models.BooleanField(default=False)
    block=models.BooleanField(default=False)
    like_dislike_history=models.CharField(max_length=5000,blank=True)
    total_likes_recieved=models.PositiveIntegerField(default=0)
    total_dislikes_recieved=models.PositiveIntegerField(default=0)
    def __str__(self):
        return self.username
    
class Message(models.Model):
    reciever=models.ForeignKey(User)
    date_and_time=models.DateTimeField()
    message_body=models.CharField(max_length=1000)
    
class Website(models.Model):
    website_domain_name=models.URLField(primary_key=True)
    rating=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    ratingD=models.DecimalField(default=2.5,max_digits=2,decimal_places=1)
    ratingW=models.DecimalField(default=2.5,max_digits=2,decimal_places=1)
    ratingM=models.DecimalField(default=2.5,max_digits=2,decimal_places=1)
    ratingY=models.DecimalField(default=2.5,max_digits=2,decimal_places=1)
    def __str__(self):
        return self.pk
    
    
    
class Comment(models.Model):
    comment_id=models.AutoField(primary_key=True)
    user=models.ForeignKey(User)
    website=models.ForeignKey(Website)
    comment=models.CharField(max_length=1000)
    sentiment=models.DecimalField(default=0,max_digits=3,decimal_places=2)
    total_likes=models.PositiveIntegerField(default=0)
    total_dislikes=models.PositiveIntegerField(default=0)
    popularity=models.PositiveIntegerField(default=0)
    date=models.DateField()
    def save(self, *args, **kwargs):
        ''' On save, update timestamps '''
        self.date = now()
        return super(Comment, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.user)+" : "+str(self.website)
class Stats(models.Model):
    website=models.OneToOneField(Website,primary_key=True)
    male_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    female_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    age_groupA_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    age_groupB_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    age_groupC_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    age_groupD_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    expert_user_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    general_user_sentiment=models.DecimalField(default=2.5,max_digits=3,decimal_places=2)
    def __str__(self):
        return 'Website:' + str(self.pk)